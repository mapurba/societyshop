/**
 * GET /
 * Home page.
 */
exports.index = (req, res) => {
  console.log('ss')
  res.send('hi');
};
