
cd Server ;
# npm i && npm start &
npm i -g pm2;
pm2 start app.js &
